Nice to take the challenge from Thumbtack!

Running environment: Java 1.7

Running method: first, please cd into the base dir and run the following command in 

terminal:

“java -jar challenge_Yang_Wang.jar”

Then, you can type in the command like “SET ex 10” or “BEGIN”.

The source code folder is also in the base dir, its name should be “Thumbtack_Challenge”.

Thanks a lot and if you have any running problems, you can contact me at:

wangyang19901026@gmail.com.